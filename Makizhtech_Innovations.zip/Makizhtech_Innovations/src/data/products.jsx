export const products = [
  {
    id: 1,
    name: "Temperature Sensor",
    description: "High precision sensor",
    price: 499,
    image: "https://via.placeholder.com/150"
  },
  {
    id: 2,
    name: "Motion Sensor",
    description: "Smart motion detection",
    price: 799,
    image: "https://via.placeholder.com/150"
  },
  {
    id: 3,
    name: "Gas Sensor",
    description: "Industrial safety sensor",
    price: 999,
    image: "https://via.placeholder.com/150"
  },
  {
    id: 4,
    name: "Humidity Sensor",
    description: "Accurate environment tracking",
    price: 599,
    image: "https://via.placeholder.com/150"
  },
  {
    id: 5,
    name: "IR Sensor",
    description: "Infrared detection module",
    price: 399,
    image: "https://via.placeholder.com/150"
  }
];
